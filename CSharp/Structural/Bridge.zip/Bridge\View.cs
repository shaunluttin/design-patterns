namespace Structural.Bridge
{
    public class View
    {
        public void DrawOn(Window window)
        {

        }
    }
}
